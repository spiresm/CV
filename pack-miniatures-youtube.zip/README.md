# Pack Miniatures YouTube — RTBF
- 6 layouts modulaires (SVG)
- Grille 6x, zones de sécurité titre/visage
- Raccourcis: forte lisibilité, contraste, sujet cadré
